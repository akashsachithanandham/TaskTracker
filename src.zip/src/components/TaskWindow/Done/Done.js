import React , {Component} from 'react';
import './Done.css'
class Done extends Component{
    render(){
        return <div class = "container">
        <div class="container-fluid">
            Done
        </div>
        </div>;
    }
}
export default Done;