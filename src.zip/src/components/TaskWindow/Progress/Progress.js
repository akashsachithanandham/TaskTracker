import React , {Component} from 'react';
import './Progress.css'
class Progress extends Component{
    render(){
        return <div class = "container ">
            <div class="container-fluid">
                Progress
            </div>
        </div>;
    }
}
export default Progress