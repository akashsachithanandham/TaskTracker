import React , {Component} from 'react';
import './ToDo.css'
class ToDo extends Component{
    render(){
        return <div class = "container">
            <div class="container-fluid">
                    To Do
            </div>
        </div>;
    }
}
export default ToDo;