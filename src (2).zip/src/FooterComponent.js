import React from "react";


export default function FooterComponent() {
  return (
    <footer>
      <div className='footer-copyright white darken-4'>
        <div className='container'>
        
          <a className='black-text text-darken-4 right' href='#!'>
          <b className='font'>StarTech</b>
          </a>
        </div>
      </div>
    </footer>
  );
}
